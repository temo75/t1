
// ფაილი აღარ გამოიყენება
export default {};
