import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Mock database for demo purposes
  const jobTitles = ["Waiter/Waitress", "Construction Worker", "Housekeeper", "Chef de Partie", "Delivery Driver", "Receptionist", "Gardener", "Sales Assistant", "Barista", "Electrician", "Plumber", "Hotel Manager", "Tour Guide", "Security Guard", "Cleaner"];
  const companies = ["Rethymno Beach Hotel", "Build Crete", "Luxury Villas", "Thalassa Restaurant", "FastFood Express", "City Hotel", "Green Landscapes", "Fashion Hub", "Crete Tours", "SafeGuard Security", "CleanCo", "Tech Solutions", "Maritime Agency"];
  const locations = ["Rethymno Center", "Adelianos Kampos", "Platanes", "Old Town", "Atsipopoulo", "Misiria", "Perivolia", "Koumbe", "Gallos"];
  const languages = ["Greek/English", "Georgian/Greek", "Greek", "Greek/English/Russian", "Greek/English/German"];

  const jobs = Array.from({ length: 300 }, (_, i) => {
    const title = jobTitles[i % jobTitles.length];
    const company = companies[i % companies.length];
    const location = locations[i % locations.length];
    const lang = languages[i % languages.length];
    const salary = `${1000 + (i % 10) * 100}€`;
    const id = i + 1;
    
    const skillsList = [
      ["Customer Service", "English", "Teamwork"],
      ["Physical Strength", "Safety", "Construction"],
      ["Cleaning", "Organization", "Attention to detail"],
      ["Cooking", "Food Safety", "Kitchen Management"],
      ["Driving", "Punctuality", "Local Area Knowledge"],
      ["Communication", "Multi-tasking", "Computer Skills"],
      ["Plants", "Landscaping", "Maintenance"],
      ["Sales", "Persuasion", "Inventory"]
    ];

    return {
      id,
      title: `${title} #${id}`,
      company,
      location,
      type: i % 3 === 0 ? "Part-time" : "Full-time",
      language: lang,
      salary,
      address: `${location}, Rethymno 741 00`,
      phone: `+30 28310 ${10000 + i}`,
      skills: skillsList[i % skillsList.length].join(", ")
    };
  });

  const seekers = Array.from({ length: 300 }, (_, i) => {
    const names = ["Giorgi L.", "Eleni P.", "Nika M.", "Maria K.", "Dimitris S.", "Anna G.", "Luka B.", "Sofia V.", "Irakli T.", "Tamar M."];
    const skillsList = [
      "Construction, Painting, Tiling",
      "Hospitality, Customer Service, Reception",
      "Delivery, Driving, Logistics",
      "Cleaning, Housekeeping",
      "Cooking, Kitchen Prep",
      "Gardening, Maintenance",
      "Sales, Retail, Cashier",
      "Barista, Coffee Making",
      "Electrician, Technical Support",
      "Plumbing, Repair Works"
    ];
    const experiences = ["1 year", "2 years", "3 years", "5 years", "7 years", "10 years", "15 years"];
    
    const id = i + 1;
    const name = names[i % names.length];
    const skills = skillsList[i % skillsList.length];
    const location = locations[i % locations.length];
    const experience = experiences[i % experiences.length];

    return {
      id,
      name: `${name} #${id}`,
      skills,
      experience,
      location,
      languages: i % 2 === 0 ? "Georgian, Greek" : "Greek, English",
      phone: `+30 690 000 ${1000 + i}`
    };
  });

  // API Routes
  app.get("/api/jobs", (req, res) => {
    res.json(jobs);
  });

  app.get("/api/seekers", (req, res) => {
    res.json(seekers);
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve("dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve("dist/index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
