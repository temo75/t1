import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import ReactMarkdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";
import './i18n';
import { 
  Briefcase, 
  Users, 
  MessageSquare, 
  Globe, 
  MapPin, 
  Euro, 
  ChevronRight, 
  Send, 
  X,
  Sparkles,
  Search,
  Building2,
  UserCircle2,
  Phone,
  Map as MapIcon,
  ExternalLink,
  Plus,
  Bookmark
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Job {
  id: number;
  title: string;
  company: string;
  location: string;
  type?: string;
  language?: string;
  salary: string;
  address?: string;
  phone?: string;
  skills?: string;
  description?: string;
  postedAt?: string;
}

interface Seeker {
  id: number;
  name: string;
  skills: string;
  experience: string;
  location: string;
  languages: string;
  phone?: string;
}

const App: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [view, setView] = useState<'home' | 'employer' | 'seeker'>('home');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [seekers, setSeekers] = useState<Seeker[]>([]);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'ai', text: string, sources?: {title: string, uri: string}[] }[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [isEmployerRegistered, setIsEmployerRegistered] = useState(false);
  const [regData, setRegData] = useState({ fullName: '', company: '', phone: '' });
  const [isPostingJob, setIsPostingJob] = useState(false);
  const [newJob, setNewJob] = useState({ title: '', description: '', location: '', salary: '', skills: '' });
  const [isPostingResume, setIsPostingResume] = useState(false);
  const [newSeekerData, setNewSeekerData] = useState({ name: '', skills: '', experience: '', location: '', phone: '' });
  const [savedJobs, setSavedJobs] = useState<number[]>([]);
  const [showSavedJobs, setShowSavedJobs] = useState(false);
  const jobsPerPage = 10;
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch('/api/jobs').then(res => res.json()).then(setJobs);
    fetch('/api/seekers').then(res => res.json()).then(setSeekers);
  }, []);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, view]);

  const filteredJobs = jobs.filter(job => 
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.skills?.toLowerCase().includes(searchQuery.toLowerCase())
  );

    const toggleSaveJob = (jobId: number) => {
    setSavedJobs(prev => 
      prev.includes(jobId) 
        ? prev.filter(id => id !== jobId) 
        : [...prev, jobId]
    );
  };

  const totalPages = Math.ceil(filteredJobs.length / jobsPerPage);
  const indexOfLastJob = currentPage * jobsPerPage;
  const indexOfFirstJob = indexOfLastJob - jobsPerPage;
  const currentJobs = filteredJobs.slice(indexOfFirstJob, indexOfLastJob);

  const filteredSeekers = seekers.filter(seeker => 
    seeker.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    seeker.skills.toLowerCase().includes(searchQuery.toLowerCase()) ||
    seeker.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalSeekerPages = Math.ceil(filteredSeekers.length / jobsPerPage);
  const indexOfLastSeeker = currentPage * jobsPerPage;
  const indexOfFirstSeeker = indexOfLastSeeker - jobsPerPage;
  const currentSeekers = filteredSeekers.slice(indexOfFirstSeeker, indexOfLastSeeker);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const toggleLanguage = () => {
    const currentLang = i18n.language.split('-')[0];
    const newLang = currentLang === 'el' ? 'ka' : 'el';
    i18n.changeLanguage(newLang);
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMsg = inputMessage;
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInputMessage('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      const model = "gemini-3-flash-preview";
      
      const isGeorgian = i18n.language.startsWith('ka');
      const systemInstruction = isGeorgian
        ? `შენ ხარ RethymnoJobs-ის უნივერსალური AI ასისტენტი. შენი მიზანია დაეხმარო ადამიანებს რეთიმნოში (კრეტა, საბერძნეთი) ცხოვრებასა და მუშაობასთან დაკავშირებულ ყველა საკითხში.
           შენი შესაძლებლობები მოიცავს:
           1. სამუშაოს ძიება: რჩევები ვაკანსიებზე (ტურიზმი, მშენებლობა, სოფლის მეურნეობა და ა.შ.).
           2. კარიერული კონსულტაცია: CV-ს შედგენა, გასაუბრებისთვის მომზადება.
           3. ლოკალური ინფორმაცია: რეთიმნოს რაიონები, ტრანსპორტი, საცხოვრებელი.
           4. იურიდიული და ადმინისტრაციული დახმარება: საბუთები, ბინადრობის ნებართვა, შრომითი უფლებები საბერძნეთში.
           5. ენობრივი დახმარება: თარგმნა ქართულიდან ბერძნულზე და პირიქით.
           6. ზოგადი დახმარება: ნებისმიერი კითხვა რეთიმნოს შესახებ.
           იყავი მეგობრული, პროფესიონალი და ყოველთვის ეცადე გასცე ამომწურავი პასუხი. გამოიყენე ქართული ენა.`
        : `Είστε ο καθολικός βοηθός AI του RethymnoJobs. Ο στόχος σας είναι να βοηθήσετε τους ανθρώπους σε όλα τα θέματα που σχετίζονται με τη ζωή και την εργασία στο Ρέθυμνο (Κρήτη, Ελλάδα).
           Οι δυνατότητές σας περιλαμβάνουν:
           1. Αναζήτηση εργασίας: Συμβουλές για κενές θέσεις (τουρισμός, κατασκευές, γεωργία κ.λπ.).
           2. Επαγγελματική συμβουλευτική: Σύνταξη βιογραφικού, προετοιμασία για συνέντευξη.
           3. Τοπικές πληροφορίες: Περιοχές του Ρεθύμνου, μεταφορές, στέγαση.
           4. Νομική και διοικητική βοήθεια: Έγγραφα, άδειες διαμονής, εργατικά δικαιώματα στην Ελλάδα.
           5. Γλωσσική βοήθεια: Μετάφραση από Γεωργιανά σε Ελληνικά και αντίστροφα.
           6. Γενική βοήθεια: Οποιαδήποτε ερώτηση σχετικά με το Ρέθυμνο.
           Να είστε φιλικοί, επαγγελματίες και να προσπαθείτε πάντα να δίνετε ολοκληρωμένες απαντήσεις. Χρησιμοποιήστε την Ελληνική γλώσσα.`;

      const response = await ai.models.generateContent({
        model,
        contents: [{ parts: [{ text: userMsg }] }],
        config: { 
          systemInstruction,
          tools: [{ googleSearch: {} }]
        }
      });

      const replyText = response.text || (isGeorgian ? "ბოდიში, პასუხის გენერირება ვერ მოხერხდა." : "Λυπάμαι, δεν βρέθηκε απάντηση.");
      
      // Extract grounding metadata if available
      const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map(chunk => ({
        title: chunk.web?.title,
        uri: chunk.web?.uri
      })).filter(s => s.title && s.uri);

      setChatMessages(prev => [...prev, { role: 'ai', text: replyText, sources: sources || [] }]);
    } catch (error) {
      console.error("Gemini API Error:", error);
      const errorMsg = i18n.language.startsWith('ka') ? "ბოდიში, კავშირის პრობლემაა." : "Συγγνώμη, υπάρχει πρόβλημα σύνδεσης.";
      setChatMessages(prev => [...prev, { role: 'ai', text: errorMsg }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans selection:bg-blue-100">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div 
            className="flex items-center gap-2 cursor-pointer" 
            onClick={() => setView('home')}
          >
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
              <Briefcase className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">
              Rethymno<span className="text-blue-600">Jobs</span>
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={toggleLanguage}
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-slate-100 hover:bg-slate-200 transition-colors text-sm font-medium"
            >
              <Globe className="w-4 h-4" />
              {t('switch_lang')}
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <AnimatePresence mode="wait">
        {view === 'home' && (
          <motion.main 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative"
          >
            {/* Background Image with Overlay */}
            <div className="absolute inset-0 h-[500px] overflow-hidden">
              <img 
                src="https://picsum.photos/seed/rethymno/1920/1080?blur=2" 
                alt="Background" 
                className="w-full h-full object-cover opacity-20"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#F8FAFC]" />
            </div>

            <div className="relative max-w-7xl mx-auto px-6 py-16 md:py-24">
              <div className="text-center mb-16 pt-12">
                <p className="text-slate-600 text-2xl font-bold max-w-2xl mx-auto">
                  {t('subtitle')}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {/* Employer Card */}
              <motion.div 
                whileHover={{ y: -8 }}
                onClick={() => setView('employer')}
                className="group relative bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all cursor-pointer overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                  <Building2 className="w-32 h-32" />
                </div>
                <div className="flex gap-4 mb-8">
                  <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    <Users className="w-8 h-8" />
                  </div>
                  <div className="flex -space-x-3">
                    <img src="https://picsum.photos/seed/hotel1/100/100" className="w-12 h-12 rounded-xl border-2 border-white object-cover" alt="Hotel" referrerPolicy="no-referrer" />
                    <img src="https://picsum.photos/seed/const1/100/100" className="w-12 h-12 rounded-xl border-2 border-white object-cover" alt="Construction" referrerPolicy="no-referrer" />
                  </div>
                </div>
                <h2 className="text-3xl font-bold mb-4">{t('i_am_employer')}</h2>
                <p className="text-slate-500 mb-8 text-lg leading-relaxed">
                  {t('find_employee')}
                </p>
                <div className="flex items-center gap-2 text-blue-600 font-bold">
                  {t('recent_seekers')} <ChevronRight className="w-5 h-5" />
                </div>
              </motion.div>

              {/* Seeker Card */}
              <motion.div 
                whileHover={{ y: -8 }}
                onClick={() => setView('seeker')}
                className="group relative bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm hover:shadow-xl hover:border-emerald-200 transition-all cursor-pointer overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                  <UserCircle2 className="w-32 h-32" />
                </div>
                <div className="flex gap-4 mb-8">
                  <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                    <Briefcase className="w-8 h-8" />
                  </div>
                  <div className="flex -space-x-3">
                    <img src="https://picsum.photos/seed/paint1/100/100" className="w-12 h-12 rounded-xl border-2 border-white object-cover" alt="Painting" referrerPolicy="no-referrer" />
                    <img src="https://picsum.photos/seed/hotel2/100/100" className="w-12 h-12 rounded-xl border-2 border-white object-cover" alt="Tourism" referrerPolicy="no-referrer" />
                  </div>
                </div>
                <h2 className="text-3xl font-bold mb-4">{t('i_am_seeker')}</h2>
                <p className="text-slate-500 mb-8 text-lg leading-relaxed">
                  {t('find_job')}
                </p>
                <div className="flex items-center gap-2 text-emerald-600 font-bold">
                  {t('recent_jobs')} <ChevronRight className="w-5 h-5" />
                </div>
              </motion.div>
            </div>

            {/* Sectors Section */}
            <div className="mt-32">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold mb-4">
                  {i18n.language.startsWith('ka') ? 'პოპულარული სექტორები' : 'Δημοφιλείς Τομείς'}
                </h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-5xl mx-auto">
                <div className="relative h-64 rounded-3xl overflow-hidden group">
                  <img src="https://picsum.photos/seed/hotel_sector/600/400" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt="Hotel" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-black/40 flex items-end p-6">
                    <h3 className="text-white font-bold text-xl">{i18n.language.startsWith('ka') ? 'სასტუმროები' : 'Ξενοδοχεία'}</h3>
                  </div>
                </div>
                <div className="relative h-64 rounded-3xl overflow-hidden group">
                  <img src="https://picsum.photos/seed/const_sector/600/400" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt="Construction" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-black/40 flex items-end p-6">
                    <h3 className="text-white font-bold text-xl">{i18n.language.startsWith('ka') ? 'მშენებლობა' : 'Κατασκευές'}</h3>
                  </div>
                </div>
                <div className="relative h-64 rounded-3xl overflow-hidden group">
                  <img src="https://picsum.photos/seed/paint_sector/600/400" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt="Painting" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-black/40 flex items-end p-6">
                    <h3 className="text-white font-bold text-xl">{i18n.language.startsWith('ka') ? 'სამღებრო სამუშაოები' : 'Ελαιοχρωματισμοί'}</h3>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Info Section */}
            <div className="mt-32 grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto border-t border-slate-200 pt-24">
              <div className="text-center md:text-left">
                <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center mb-6 text-blue-600 mx-auto md:mx-0">
                  <Phone className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">{t('phone')}</h3>
                <p className="text-slate-500">-</p>
              </div>
              <div className="text-center md:text-left">
                <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center mb-6 text-emerald-600 mx-auto md:mx-0">
                  <MapIcon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">{t('address')}</h3>
                <p className="text-slate-500">Rethymno, Crete, Greece</p>
                <p className="text-slate-500 mb-4">741 00</p>
                <a 
                  href="https://www.google.com/maps/search/?api=1&query=Rethymno+Crete+Greece"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-600 font-bold text-sm hover:underline flex items-center gap-1 justify-center md:justify-start"
                >
                  <ExternalLink className="w-4 h-4" /> {t('view_on_map')}
                </a>
              </div>
              <div className="text-center md:text-left">
                <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center mb-6 text-purple-600 mx-auto md:mx-0">
                  <Globe className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Email</h3>
                <p className="text-slate-500">temo75elia@gmail.com</p>
              </div>
            </div>
          </div>
        </motion.main>
      )}

        {/* Employer View (Listing Seekers) */}
        {view === 'employer' && (
          <motion.main 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="max-w-5xl mx-auto px-6 py-12"
          >
            {!isEmployerRegistered ? (
              <div className="max-w-md mx-auto bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-xl">
                <div className="text-center mb-8">
                  <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-blue-600">
                    <UserCircle2 className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-bold">{t('employer_registration')}</h2>
                </div>
                <form 
                  onSubmit={(e) => { e.preventDefault(); setIsEmployerRegistered(true); }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">{t('full_name')}</label>
                    <input 
                      required
                      type="text" 
                      value={regData.fullName}
                      onChange={(e) => setRegData({...regData, fullName: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">{t('company_name')}</label>
                    <input 
                      required
                      type="text" 
                      value={regData.company}
                      onChange={(e) => setRegData({...regData, company: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">{t('phone')}</label>
                    <input 
                      required
                      type="tel" 
                      value={regData.phone}
                      onChange={(e) => setRegData({...regData, phone: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <button 
                    type="submit"
                    className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 mt-6"
                  >
                    {t('register')}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setView('home')}
                    className="w-full py-2 text-slate-400 font-medium hover:text-slate-600 transition-all"
                  >
                    {i18n.language.startsWith('ka') ? 'უკან' : 'Πίσω'}
                  </button>
                </form>
              </div>
            ) : (
              <>
                {isPostingJob ? (
                  <div className="max-w-2xl mx-auto bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-xl">
                    <div className="flex items-center justify-between mb-8">
                      <h2 className="text-3xl font-bold">{t('post_job')}</h2>
                      <button 
                        onClick={() => setIsPostingJob(false)}
                        className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                      >
                        <X className="w-6 h-6 text-slate-400" />
                      </button>
                    </div>
                    <form 
                      onSubmit={(e) => { 
                        e.preventDefault(); 
                        const jobToAdd: Job = {
                          id: Date.now(),
                          title: newJob.title,
                          company: regData.company,
                          location: newJob.location,
                          salary: newJob.salary,
                          description: newJob.description,
                          skills: newJob.skills,
                          postedAt: new Date().toISOString()
                        };
                        setJobs([jobToAdd, ...jobs]);
                        setIsPostingJob(false);
                        setNewJob({ title: '', description: '', location: '', salary: '', skills: '' });
                      }}
                      className="space-y-6"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-bold text-slate-700 mb-1">{t('job_title')}</label>
                          <input 
                            required
                            type="text" 
                            value={newJob.title}
                            onChange={(e) => setNewJob({...newJob, title: e.target.value})}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-bold text-slate-700 mb-1">{t('job_location')}</label>
                          <input 
                            required
                            type="text" 
                            value={newJob.location}
                            onChange={(e) => setNewJob({...newJob, location: e.target.value})}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-bold text-slate-700 mb-1">{t('job_salary')}</label>
                          <input 
                            type="text" 
                            value={newJob.salary}
                            onChange={(e) => setNewJob({...newJob, salary: e.target.value})}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-bold text-slate-700 mb-1">{t('job_skills')}</label>
                          <input 
                            type="text" 
                            value={newJob.skills}
                            onChange={(e) => setNewJob({...newJob, skills: e.target.value})}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-slate-700 mb-1">{t('job_description')}</label>
                        <textarea 
                          required
                          rows={4}
                          value={newJob.description}
                          onChange={(e) => setNewJob({...newJob, description: e.target.value})}
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                        />
                      </div>
                      <div className="flex gap-4">
                        <button 
                          type="button"
                          onClick={() => setIsPostingJob(false)}
                          className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
                        >
                          {t('cancel')}
                        </button>
                        <button 
                          type="submit"
                          className="flex-1 py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                        >
                          {t('submit_job')}
                        </button>
                      </div>
                    </form>
                  </div>
                ) : (
                  <>
                    <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-12">
                      <div className="flex items-center gap-6">
                        <h2 className="text-4xl font-black tracking-tight">{t('recent_seekers')}</h2>
                        <button 
                          onClick={() => setIsPostingJob(true)}
                          className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 flex items-center gap-2"
                        >
                          <Plus className="w-5 h-5" /> {t('post_job')}
                        </button>
                      </div>
                      <div className="flex items-center gap-4 w-full md:w-auto">
                    <div className="relative flex-grow md:w-64">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="Search seekers..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                      />
                    </div>
                    <button 
                      onClick={() => { setView('home'); setSearchQuery(''); }}
                      className="text-slate-400 hover:text-slate-900 font-medium whitespace-nowrap"
                    >
                      ← Back
                    </button>
                  </div>
                </div>
                <div className="grid gap-6">
                  {currentSeekers.map((seeker, index) => (
                    <div key={seeker.id} className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-all relative overflow-hidden">
                      <div className="absolute top-0 left-0 bg-slate-100 px-3 py-1 text-[10px] font-bold text-slate-400 rounded-br-xl">
                        #{indexOfFirstSeeker + index + 1}
                      </div>
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-2xl font-bold mb-1">{seeker.name}</h3>
                          <div className="flex flex-col gap-2 text-slate-500 text-sm">
                            <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {seeker.location}</span>
                            <span className="flex items-center gap-1"><Users className="w-4 h-4" /> {seeker.experience}</span>
                            {seeker.phone && (
                              <span className="flex items-center gap-1 text-blue-600 font-medium">
                                <Phone className="w-4 h-4" /> {seeker.phone}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <a 
                            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(seeker.location + ' Crete Greece')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-slate-100 text-slate-700 px-6 py-2 rounded-full font-bold text-sm hover:bg-slate-200 transition-colors flex items-center gap-2 justify-center"
                          >
                            <MapIcon className="w-4 h-4" /> {t('view_on_map')}
                          </a>
                          <a 
                            href={`tel:${seeker.phone}`}
                            className="bg-blue-600 text-white px-6 py-2 rounded-full font-bold text-sm hover:bg-blue-700 transition-colors flex items-center gap-2 justify-center"
                          >
                            <Phone className="w-4 h-4" /> {t('contact')}
                          </a>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-6">
                        {seeker.skills.split(',').map(skill => (
                          <span key={skill} className="px-4 py-1.5 bg-slate-100 rounded-full text-xs font-bold text-slate-600 uppercase tracking-wider">
                            {skill.trim()}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pagination */}
                {totalSeekerPages > 1 && (
                  <div className="mt-12 flex items-center justify-center gap-2">
                    <button 
                      disabled={currentPage === 1}
                      onClick={() => {
                        setCurrentPage(prev => Math.max(1, prev - 1));
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-sm font-bold disabled:opacity-50 hover:bg-slate-50 transition-colors"
                    >
                      {i18n.language.startsWith('ka') ? 'წინა' : 'Προηγούμενο'}
                    </button>
                    
                    <div className="flex items-center gap-1">
                      {Array.from({ length: Math.min(5, totalSeekerPages) }, (_, i) => {
                        let pageNum = currentPage;
                        if (totalSeekerPages <= 5) pageNum = i + 1;
                        else if (currentPage <= 3) pageNum = i + 1;
                        else if (currentPage >= totalSeekerPages - 2) pageNum = totalSeekerPages - 4 + i;
                        else pageNum = currentPage - 2 + i;

                        if (pageNum <= 0 || pageNum > totalSeekerPages) return null;

                        return (
                          <button
                            key={pageNum}
                            onClick={() => {
                              setCurrentPage(pageNum);
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            className={cn(
                              "w-10 h-10 rounded-xl text-sm font-bold transition-all",
                              currentPage === pageNum 
                                ? "bg-blue-600 text-white shadow-lg shadow-blue-100" 
                                : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
                            )}
                          >
                            {pageNum}
                          </button>
                        );
                      })}
                    </div>

                    <button 
                      disabled={currentPage === totalSeekerPages}
                      onClick={() => {
                        setCurrentPage(prev => Math.min(totalSeekerPages, prev + 1));
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-sm font-bold disabled:opacity-50 hover:bg-slate-50 transition-colors"
                    >
                      {i18n.language.startsWith('ka') ? 'შემდეგი' : 'Επόμενο'}
                    </button>
                  </div>
                )}
              </>
            )}
          </>
        )}
      </motion.main>
    )}

        {/* Seeker View (Listing Jobs) */}
        {view === 'seeker' && (
          <motion.main 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="max-w-5xl mx-auto px-6 py-12"
          >
            {isPostingResume ? (
              <div className="max-w-2xl mx-auto bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-xl">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-3xl font-bold">{t('post_resume')}</h2>
                  <button 
                    onClick={() => setIsPostingResume(false)}
                    className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                  >
                    <X className="w-6 h-6 text-slate-400" />
                  </button>
                </div>
                <form 
                  onSubmit={(e) => { 
                    e.preventDefault(); 
                    const seekerToAdd: Seeker = {
                      id: Date.now(),
                      name: newSeekerData.name,
                      skills: newSeekerData.skills,
                      experience: newSeekerData.experience,
                      location: newSeekerData.location,
                      languages: 'Greek, English', // Default
                      phone: newSeekerData.phone
                    };
                    setSeekers([seekerToAdd, ...seekers]);
                    setIsPostingResume(false);
                    setNewSeekerData({ name: '', skills: '', experience: '', location: '', phone: '' });
                  }}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t('your_name')}</label>
                      <input 
                        required
                        type="text" 
                        value={newSeekerData.name}
                        onChange={(e) => setNewSeekerData({...newSeekerData, name: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t('your_location')}</label>
                      <input 
                        required
                        type="text" 
                        value={newSeekerData.location}
                        onChange={(e) => setNewSeekerData({...newSeekerData, location: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t('your_phone')}</label>
                      <input 
                        required
                        type="tel" 
                        value={newSeekerData.phone}
                        onChange={(e) => setNewSeekerData({...newSeekerData, phone: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-1">{t('your_experience')}</label>
                      <input 
                        required
                        type="text" 
                        value={newSeekerData.experience}
                        onChange={(e) => setNewSeekerData({...newSeekerData, experience: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">{t('your_skills')}</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g. Painting, Construction, Cleaning"
                      value={newSeekerData.skills}
                      onChange={(e) => setNewSeekerData({...newSeekerData, skills: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                  <div className="flex gap-4">
                    <button 
                      type="button"
                      onClick={() => setIsPostingResume(false)}
                      className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-all"
                    >
                      {t('cancel')}
                    </button>
                    <button 
                      type="submit"
                      className="flex-1 py-4 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                    >
                      {t('submit_resume')}
                    </button>
                  </div>
                </form>
              </div>
            ) : (<>
                <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-12">
                  <div className="flex items-center gap-6">
                    <h2 className="text-4xl font-black tracking-tight">{t('recent_jobs')}</h2>
                    <button 
                      onClick={() => setIsPostingResume(true)}
                      className="bg-emerald-600 text-white px-6 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 flex items-center gap-2"
                    >
                      <Plus className="w-5 h-5" /> {t('post_resume')}
                    </button>
                    <button 
                      onClick={() => setShowSavedJobs(!showSavedJobs)}
                      className={`${showSavedJobs ? 'bg-blue-600 text-white' : 'bg-white text-slate-700'} px-6 py-3 rounded-2xl font-bold hover:bg-blue-100 transition-all shadow-lg shadow-blue-100 flex items-center gap-2`}
                    >
                      <Bookmark className="w-5 h-5" /> {showSavedJobs ? t('all_jobs') : t('my_saved_jobs')}
                    </button>
                  </div>
                  <div className="flex items-center gap-4 w-full md:w-auto">
                    <div className="relative flex-grow md:w-64">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="Search jobs..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                      />
                    </div>
                    <button 
                      onClick={() => { setView('home'); setSearchQuery(''); }} 
                      className="text-slate-400 hover:text-slate-900 font-medium whitespace-nowrap"
                    >
                      ← Back
                    </button>
                  </div>
                </div>
                <div className="grid gap-6">
                  {(showSavedJobs ? jobs.filter(j => savedJobs.includes(j.id)) : currentJobs).map((job, index) => (
                    <div key={job.id} className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-all relative overflow-hidden">
                      <div className="absolute top-0 left-0 bg-slate-100 px-3 py-1 text-[10px] font-bold text-slate-400 rounded-br-xl">
                        #{indexOfFirstJob + index + 1}
                      </div>
                      <div className="flex flex-col md:flex-row justify-between items-start gap-6">
                        <div className="flex-grow">
                          <h3 className="text-2xl font-bold mb-1">{job.title}</h3>
                          <p className="text-blue-600 font-bold mb-3">{job.company}</p>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-500 text-sm mb-6">
                            <span className="flex items-center gap-2"><MapPin className="w-4 h-4 text-slate-400" /> {job.location}</span>
                            <span className="flex items-center gap-2"><Euro className="w-4 h-4 text-slate-400" /> {job.salary}</span>
                            {job.address && (
                              <span className="flex items-center gap-2 col-span-full">
                                <MapIcon className="w-4 h-4 text-slate-400" /> 
                                <span className="italic">{job.address}</span>
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap gap-3">
                            <span className="px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider">
                              {job.type}
                            </span>
                            <span className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded-full text-xs font-bold uppercase tracking-wider">
                              {job.language}
                            </span>
                          </div>

                          {job.skills && (
                            <div className="flex flex-wrap gap-2 mt-4">
                              {job.skills.split(',').map(skill => (
                                <span key={skill} className="px-3 py-1 bg-slate-50 text-slate-500 rounded-lg text-[10px] font-bold uppercase tracking-tight border border-slate-100">
                                  {skill.trim()}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>

                        <div className="flex flex-col gap-3 w-full md:w-auto">
                          <a 
                            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(job.address || job.location)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-200 transition-all"
                          >
                            <MapIcon className="w-4 h-4" /> {t('view_on_map')}
                          </a>
                          <a 
                            href={`tel:${job.phone}`}
                            className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                          >
                            <Phone className="w-4 h-4" /> {t('contact')}
                          </a>
                          <button 
                            onClick={() => toggleSaveJob(job.id)}
                            className={`flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all ${savedJobs.includes(job.id) ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                          >
                            <Bookmark className={`w-4 h-4 ${savedJobs.includes(job.id) ? 'fill-white' : ''}`} /> {savedJobs.includes(job.id) ? t('saved') : t('save')}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="mt-12 flex items-center justify-center gap-2">
                    <button 
                      disabled={currentPage === 1}
                      onClick={() => {
                        setCurrentPage(prev => Math.max(1, prev - 1));
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-sm font-bold disabled:opacity-50 hover:bg-slate-50 transition-colors"
                    >
                      {i18n.language.startsWith('ka') ? 'წინა' : 'Προηγούμενο'}
                    </button>
                    
                    <div className="flex items-center gap-1">
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        let pageNum = currentPage;
                        if (totalPages <= 5) pageNum = i + 1;
                        else if (currentPage <= 3) pageNum = i + 1;
                        else if (currentPage >= totalPages - 2) pageNum = totalPages - 4 + i;
                        else pageNum = currentPage - 2 + i;

                        if (pageNum <= 0 || pageNum > totalPages) return null;

                        return (
                          <button
                            key={pageNum}
                            onClick={() => {
                              setCurrentPage(pageNum);
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            className={cn(
                              "w-10 h-10 rounded-xl text-sm font-bold transition-all",
                              currentPage === pageNum 
                                ? "bg-emerald-600 text-white shadow-lg shadow-emerald-100" 
                                : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
                            )}
                          >
                            {pageNum}
                          </button>
                        );
                      })}
                    </div>

                    <button 
                      disabled={currentPage === totalPages}
                      onClick={() => {
                        setCurrentPage(prev => Math.min(totalPages, prev + 1));
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-sm font-bold disabled:opacity-50 hover:bg-slate-50 transition-colors"
                    >
                      {i18n.language.startsWith('ka') ? 'შემდეგი' : 'Επόμενο'}
                    </button>
                  </div>
                )}
              </>)}</motion.main>
        )}
      </AnimatePresence>

      {/* AI Chatbot */}
      <AnimatePresence>
        {isChatOpen && (
          <>
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsChatOpen(false)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50"
            />
            
            {/* Centered Chat Window */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20, x: '-50%', left: '50%', top: '50%' }}
              animate={{ opacity: 1, scale: 1, y: '-50%', x: '-50%', left: '50%', top: '50%' }}
              exit={{ opacity: 0, scale: 0.9, y: 20, x: '-50%', left: '50%', top: '50%' }}
              className="fixed z-50 w-[95vw] md:w-[500px] h-[600px] bg-white rounded-[2.5rem] shadow-2xl border border-slate-200 flex flex-col overflow-hidden"
            >
              {/* Chat Header */}
              <div className="p-6 bg-blue-600 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">{t('ai_assistant')}</h3>
                    <p className="text-[10px] opacity-70 uppercase tracking-widest font-black">Powered by Gemini</p>
                  </div>
                </div>
                <button onClick={() => setIsChatOpen(false)} className="hover:bg-white/10 p-1 rounded-lg transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Messages */}
              <div className="flex-grow overflow-y-auto p-6 space-y-4 bg-slate-50">
                {chatMessages.length === 0 && (
                  <div className="text-center py-12">
                    <Sparkles className="w-12 h-12 text-blue-200 mx-auto mb-4" />
                    <p className="text-slate-400 text-sm">{t('chat_placeholder')}</p>
                  </div>
                )}
                {chatMessages.map((msg, i) => (
                  <div key={i} className={cn(
                    "max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed",
                    msg.role === 'user' 
                      ? "ml-auto bg-blue-600 text-white rounded-tr-none" 
                      : "mr-auto bg-white border border-slate-200 text-slate-700 rounded-tl-none shadow-sm"
                  )}>
                    <div className="prose prose-sm prose-slate max-w-none dark:prose-invert">
                      <ReactMarkdown>{msg.text}</ReactMarkdown>
                    </div>
                    {msg.sources && msg.sources.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-slate-100">
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Sources:</p>
                        <div className="flex flex-col gap-1">
                          {msg.sources.map((source, idx) => (
                            <a 
                              key={idx} 
                              href={source.uri} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-[11px] text-blue-600 hover:underline flex items-center gap-1 truncate"
                            >
                              <Globe className="w-3 h-3 flex-shrink-0" />
                              {source.title}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                {isTyping && (
                  <div className="mr-auto bg-white border border-slate-200 p-4 rounded-2xl rounded-tl-none shadow-sm">
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce" />
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Input */}
              <div className="p-4 bg-white border-t border-slate-100">
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder={t('chat_placeholder')}
                    className="flex-grow bg-slate-100 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                  <button 
                    onClick={handleSendMessage}
                    disabled={isTyping}
                    className="bg-blue-600 text-white p-3 rounded-xl hover:bg-blue-700 transition-colors disabled:bg-slate-300"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Floating Chat Button */}
      <div className="fixed bottom-8 right-8 z-40">
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-xl shadow-blue-300 hover:bg-blue-700 transition-all"
        >
          {isChatOpen ? <X className="w-8 h-8" /> : <MessageSquare className="w-8 h-8" />}
        </motion.button>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-12 mt-24">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2 grayscale opacity-50">
            <Briefcase className="w-5 h-5" />
            <span className="text-lg font-bold tracking-tight">RethymnoJobs</span>
          </div>
          <div className="flex gap-8 text-xs font-bold text-slate-400 uppercase tracking-widest">
            <a href="#" className="hover:text-blue-600 transition-colors">About</a>
            <a href="#" className="hover:text-blue-600 transition-colors">Privacy</a>
            <a href="#" className="hover:text-blue-600 transition-colors">Contact</a>
          </div>
          <p className="text-slate-400 text-xs">© 2025 RethymnoJobs. Crete, Greece.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
