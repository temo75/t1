import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  el: {
    translation: {
      "welcome": "Καλώς ήρθατε στο RethymnoJobs",
      "subtitle": "Συνδέοντας την τοπική αγορά εργασίας",
      "i_am_employer": "Είμαι Εργοδότης",
      "i_am_seeker": "Ψάχνω για Δουλειά",
      "find_employee": "Βρείτε Προσωπικό",
      "find_job": "Βρείτε Εργασία",
      "recent_jobs": "Πρόσφατες Θέσεις Εργασίας",
      "recent_seekers": "Διαθέσιμοι Εργαζόμενοι",
      "chat_placeholder": "Πώς μπορώ να σας βοηθήσω να βρείτε δουλειά;",
      "send": "Αποστολή",
      "location": "Τοποθεσία",
      "salary": "Μισθός",
      "skills": "Δεξιότητες",
      "experience": "Εμπειρία",
      "languages": "Γλώσσες",
      "ai_assistant": "Βοηθός AI",
      "switch_lang": "ქართული",
      "address": "Διεύθυνση",
      "phone": "Τηλέφωνο",
      "view_on_map": "Προβολή στο χάρτη",
      "contact": "Επικοινωνία",
      "registration": "Εγγραφή",
      "full_name": "Ονοματεπώνυμο",
      "company_name": "Όνομα Εταιρείας",
      "register": "Εγγραφή",
      "employer_registration": "Εγγραφή Εργοδότη",
      "post_job": "Δημοσίευση Θέσης",
      "job_title": "Τίτλος Θέσης",
      "job_description": "Περιγραφή",
      "job_location": "Τοποθεσία",
      "job_salary": "Μισθός",
      "job_skills": "Δεξιότητες (χωρισμένες με κόμμα)",
      "submit_job": "Δημοσίευση",
      "cancel": "Ακύρωση",
      "post_resume": "Δημοσίευση Βιογραφικού",
      "your_name": "Το Όνομά σας",
      "your_skills": "Οι Δεξιότητές σας",
      "your_experience": "Η Εμπειρία σας",
      "your_location": "Η Τοποθεσία σας",
      "your_phone": "Το Τηλέφωνό σας",
      "submit_resume": "Δημοσίευση Βιογραφικού",
      "all_jobs": "Όλες οι θέσεις",
      "my_saved_jobs": "Οι αποθηκευμένες μου θέσεις",
      "saved": "Αποθηκευμένο",
      "save": "Αποθήκευση"
    }
  },
  ka: {
    translation: {
      "welcome": "კეთილი იყოს თქვენი მობრძანება RethymnoJobs-ზე",
      "subtitle": "ადგილობრივი შრომის ბაზრის დაკავშირება",
      "i_am_employer": "მე ვარ დამსაქმებელი",
      "i_am_seeker": "ვეძებ სამუშაოს",
      "find_employee": "იპოვეთ თანამშრომელი",
      "find_job": "იპოვეთ სამუშაო",
      "recent_jobs": "ბოლო ვაკანსიები",
      "recent_seekers": "ხელმისაწვდომი კადრები",
      "chat_placeholder": "როგორ დაგეხმაროთ სამუშაოს პოვნაში?",
      "send": "გაგზავნა",
      "location": "მდებარეობა",
      "salary": "ხელფასი",
      "skills": "უნარები",
      "experience": "გამოცდილება",
      "languages": "ენები",
      "ai_assistant": "AI ასისტენტი",
      "switch_lang": "Ελληνικά",
      "address": "მისამართი",
      "phone": "ტელეფონი",
      "view_on_map": "რუკაზე ნახვა",
      "contact": "კონტაქტი",
      "registration": "რეგისტრაცია",
      "full_name": "სახელი და გვარი",
      "company_name": "კომპანიის სახელი",
      "register": "რეგისტრაცია",
      "employer_registration": "დამსაქმებლის რეგისტრაცია",
      "post_job": "ვაკანსიის დამატება",
      "job_title": "ვაკანსიის დასახელება",
      "job_description": "აღწერა",
      "job_location": "მდებარეობა",
      "job_salary": "ხელფასი",
      "job_skills": "უნარები (მძიმით გამოყოფილი)",
      "submit_job": "გამოქვეყნება",
      "cancel": "გაუქმება",
      "post_resume": "რეზიუმეს დამატება",
      "your_name": "თქვენი სახელი",
      "your_skills": "თქვენი უნარები",
      "your_experience": "თქვენი გამოცდილება",
      "your_location": "თქვენი მდებარეობა",
      "your_phone": "თქვენი ტელეფონი",
      "submit_resume": "რეზიუმეს გამოქვეყნება",
      "all_jobs": "ყველა ვაკანსია",
      "my_saved_jobs": "ჩემი შენახული ვაკანსიები",
      "saved": "შენახულია",
      "save": "შენახვა"
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'el',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
