import React, { useState, useEffect, useCallback } from 'react';
import { 
  Youtube, 
  Link as LinkIcon, 
  Download, 
  Music, 
  Video, 
  Loader2,
  CheckCircle2,
  AlertCircle,
  Clock,
  FileAudio,
  FileVideo,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface VideoInfo {
  title: string;
  thumbnail: string;
  duration: number;
}

const App: React.FC = () => {
  const [url, setUrl] = useState('');
  const [info, setInfo] = useState<VideoInfo | null>(null);
  const [isLoadingInfo, setIsLoadingInfo] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState('');

  const fetchInfo = async (videoUrl: string) => {
    if (!videoUrl) return;
    setIsLoadingInfo(true);
    setError(null);
    try {
      const res = await fetch(`/api/info?url=${encodeURIComponent(videoUrl)}`);
      if (!res.ok) throw new Error('ვიდეოს ინფორმაცია ვერ მოიძებნა');
      const data = await res.json();
      setInfo(data);
    } catch (err: any) {
      setError(err.message);
      setInfo(null);
    } finally {
      setIsLoadingInfo(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      if (url.includes('youtube.com') || url.includes('youtu.be')) {
        fetchInfo(url);
      }
    }, 800);
    return () => clearTimeout(timer);
  }, [url]);

  const handleDownload = async (format: 'mp3' | 'mp4') => {
    if (!url || isDownloading) return;
    setIsDownloading(true);
    setStatus('მზადდება ჩამოსატვირთად...');
    setError(null);

    try {
      const response = await fetch(`/api/download?url=${encodeURIComponent(url)}&format=${format}`);
      if (!response.ok) {
        const msg = await response.text();
        throw new Error(msg || 'ჩამოტვირთვა ვერ მოხერხდა');
      }

      const data = await response.json();
      
      if (data.downloadUrl) {
        // Open the download URL in a new tab or trigger it
        window.location.href = data.downloadUrl;
        setStatus('დასრულდა!');
      } else {
        throw new Error('ჩამოტვირთვის ბმული ვერ მოიძებნა');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsDownloading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-white font-sans selection:bg-pink-500/30">
      {/* Navbar */}
      <nav className="border-b border-white/5 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl flex items-center justify-center shadow-lg shadow-pink-500/20">
              <Youtube className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-black tracking-tighter">
              Y2<span className="text-pink-500">MATE</span>.GE
            </span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
            <a href="#" className="hover:text-white transition-colors">YouTube to MP3</a>
            <a href="#" className="hover:text-white transition-colors">YouTube to MP4</a>
            <a href="#" className="hover:text-white transition-colors">FAQ</a>
          </div>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-6 py-16 md:py-24">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-black mb-6 tracking-tight"
          >
            ჩამოტვირთე ვიდეო და აუდიო <br />
            <span className="bg-gradient-to-r from-pink-500 via-rose-500 to-amber-500 bg-clip-text text-transparent">
              სრულიად უფასოდ
            </span>
          </motion.h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            საუკეთესო გზა YouTube ვიდეოების MP3 და MP4 ფორმატში გადასაყვანად. 
            სწრაფი, უსაფრთხო და მარტივი.
          </p>
        </div>

        {/* Search Box */}
        <div className="relative max-w-3xl mx-auto mb-12">
          <div className="absolute -inset-1 bg-gradient-to-r from-pink-500 to-rose-600 rounded-2xl blur opacity-20" />
          <div className="relative flex flex-col md:flex-row gap-3 bg-slate-900 border border-white/10 p-2 rounded-2xl shadow-2xl">
            <div className="flex-grow flex items-center px-4">
              <LinkIcon className="w-5 h-5 text-slate-500 mr-3" />
              <input 
                type="text" 
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="ჩასვით YouTube ბმული აქ..."
                className="w-full bg-transparent py-4 outline-none text-lg placeholder:text-slate-600"
              />
            </div>
            <button 
              onClick={() => fetchInfo(url)}
              disabled={isLoadingInfo}
              className="bg-pink-600 hover:bg-pink-500 disabled:bg-slate-800 text-white font-bold px-10 py-4 rounded-xl transition-all flex items-center justify-center gap-2"
            >
              {isLoadingInfo ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-5 h-5" />}
              დაწყება
            </button>
          </div>
        </div>

        {/* Error Message */}
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="max-w-3xl mx-auto mb-8"
            >
              <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-xl flex items-center gap-3 text-rose-500">
                <AlertCircle className="w-5 h-5" />
                <span className="text-sm font-medium">{error}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Result Section */}
        <AnimatePresence>
          {info && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-3xl mx-auto"
            >
              <div className="bg-slate-900/50 border border-white/10 rounded-3xl overflow-hidden backdrop-blur-sm">
                <div className="flex flex-col md:flex-row">
                  {/* Thumbnail */}
                  <div className="w-full md:w-72 relative group">
                    <img 
                      src={info.thumbnail} 
                      alt={info.title} 
                      className="w-full h-full object-cover aspect-video md:aspect-square"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Youtube className="w-12 h-12 text-white" />
                    </div>
                    <div className="absolute bottom-3 right-3 bg-black/80 px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDuration(info.duration)}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-grow p-8 flex flex-col justify-between">
                    <div>
                      <h2 className="text-xl font-bold mb-6 line-clamp-2 leading-tight">
                        {info.title}
                      </h2>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <button 
                          onClick={() => handleDownload('mp3')}
                          disabled={isDownloading}
                          className="flex items-center justify-between bg-slate-800 hover:bg-slate-700 p-4 rounded-2xl transition-colors group"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-pink-500/10 rounded-lg flex items-center justify-center text-pink-500">
                              <FileAudio className="w-5 h-5" />
                            </div>
                            <div className="text-left">
                              <p className="text-sm font-bold">Audio MP3</p>
                              <p className="text-[10px] text-slate-500 uppercase font-black">320kbps</p>
                            </div>
                          </div>
                          <Download className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
                        </button>

                        <button 
                          onClick={() => handleDownload('mp4')}
                          disabled={isDownloading}
                          className="flex items-center justify-between bg-slate-800 hover:bg-slate-700 p-4 rounded-2xl transition-colors group"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-rose-500/10 rounded-lg flex items-center justify-center text-rose-500">
                              <FileVideo className="w-5 h-5" />
                            </div>
                            <div className="text-left">
                              <p className="text-sm font-bold">Video MP4</p>
                              <p className="text-[10px] text-slate-500 uppercase font-black">720p HD</p>
                            </div>
                          </div>
                          <Download className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
                        </button>
                      </div>
                    </div>

                    {isDownloading && (
                      <div className="mt-8 pt-8 border-t border-white/5">
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{status}</span>
                          <Loader2 className="w-4 h-4 animate-spin text-pink-500" />
                        </div>
                        <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                          <motion.div 
                            className="h-full bg-pink-500"
                            animate={{ x: ['-100%', '100%'] }}
                            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-32">
          {[
            { icon: <Download className="w-6 h-6" />, title: "სწრაფი ჩამოტვირთვა", desc: "ჩვენი სერვერები უზრუნველყოფენ მაქსიმალურ სიჩქარეს." },
            { icon: <ShieldCheck className="w-6 h-6" />, title: "უსაფრთხოება", desc: "არანაირი ვირუსი ან რეკლამა. მხოლოდ სუფთა ფაილები." },
            { icon: <CheckCircle2 className="w-6 h-6" />, title: "ხარისხი", desc: "საუკეთესო აუდიო და ვიდეო ხარისხი რაც კი ხელმისაწვდომია." }
          ].map((feature, i) => (
            <div key={i} className="bg-slate-900/30 border border-white/5 p-8 rounded-3xl hover:border-pink-500/30 transition-colors group">
              <div className="w-12 h-12 bg-slate-800 rounded-2xl flex items-center justify-center mb-6 text-slate-400 group-hover:text-pink-500 transition-colors">
                {feature.icon}
              </div>
              <h3 className="text-lg font-bold mb-3">{feature.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-12 bg-slate-950">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3 grayscale opacity-50">
            <Youtube className="w-5 h-5" />
            <span className="text-lg font-black tracking-tighter">Y2MATE.GE</span>
          </div>
          <div className="flex gap-8 text-xs font-bold text-slate-600 uppercase tracking-widest">
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
          </div>
          <p className="text-slate-600 text-xs">© 2025 Y2MATE GEORGIA. All rights reserved.</p>
        </div>
      </footer>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
      `}</style>
    </div>
  );
};

const ShieldCheck = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
);

export default App;
