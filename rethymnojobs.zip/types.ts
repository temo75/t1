
export interface VideoAnalysis {
  id: string;
  url: string;
  summary: string;
  suggestedQuality: string;
}
