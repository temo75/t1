
// AI სერვისი ამოღებულია მომხმარებლის მოთხოვნით
export const analyzeYoutubeVideo = async () => { return ""; };
